<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ingredientstock";
    $mysqli = new mysqli($servername,$username,$password,$dbname) or die($mysqli->error);
?>
